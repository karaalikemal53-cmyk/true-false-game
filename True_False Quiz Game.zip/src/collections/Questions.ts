import { revalidateTag } from 'next/cache'
import type { Access, CollectionConfig } from 'payload'

const isPayloadAdmin: Access = ({ req }) => req.user?.collection === 'admins'

export const Questions: CollectionConfig = {
  slug: 'questions',
  defaultSort: 'order',
  labels: {
    singular: 'Soru',
    plural: 'Sorular',
  },
  access: {
    create: isPayloadAdmin,
    delete: isPayloadAdmin,
    read: () => true,
    update: isPayloadAdmin,
  },
  admin: {
    group: 'Oyun',
    useAsTitle: 'statement',
    defaultColumns: ['order', 'statement', 'category', 'answer'],
    description: 'Oyunda ilk 15 soru, sıra numarasına göre gösterilir.',
  },
  hooks: {
    afterChange: [
      ({ doc }) => {
        revalidateTag('quiz-questions', 'max')
        return doc
      },
    ],
    afterDelete: [
      ({ doc }) => {
        revalidateTag('quiz-questions', 'max')
        return doc
      },
    ],
  },
  fields: [
    {
      name: 'order',
      label: 'Sıra',
      type: 'number',
      min: 1,
      max: 999,
      required: true,
      admin: {
        description: 'Sorunun oyundaki sırası.',
        position: 'sidebar',
      },
    },
    {
      name: 'category',
      label: 'Kategori',
      type: 'text',
      required: true,
      admin: {
        placeholder: 'Örn. Fen Bilimleri',
      },
    },
    {
      name: 'statement',
      label: 'Soru metni',
      type: 'textarea',
      required: true,
    },
    {
      name: 'answer',
      label: 'Doğru cevap',
      type: 'select',
      required: true,
      options: [
        { label: 'Doğru', value: 'true' },
        { label: 'Yanlış', value: 'false' },
      ],
      admin: {
        position: 'sidebar',
      },
    },
    {
      name: 'explanation',
      label: 'Cevap açıklaması',
      type: 'textarea',
      required: true,
      admin: {
        description: 'İki oyuncu da cevapladıktan sonra gösterilir.',
      },
    },
  ],
}
