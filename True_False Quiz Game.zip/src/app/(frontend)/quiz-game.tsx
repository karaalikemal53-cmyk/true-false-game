'use client'

import Link from 'next/link'
import { useEffect, useMemo, useState, type CSSProperties } from 'react'

type Answer = boolean | null
type Screen = 'welcome' | 'quiz' | 'results'

export type GameQuestion = {
  id: string
  statement: string
  answer: boolean
  explanation: string
  category: string
}

const QUESTION_TIME = 15
const REQUIRED_QUESTION_COUNT = 15

function SparkIcon() {
  return <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2.5c.8 5.8 3.7 8.7 9.5 9.5-5.8.8-8.7 3.7-9.5 9.5-.8-5.8-3.7-8.7-9.5-9.5C8.3 11.2 11.2 8.3 12 2.5Z" /></svg>
}

function ArrowIcon() {
  return <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6" /></svg>
}

function RestartIcon() {
  return <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 4v6h6M5.5 16.5a8 8 0 1 0 .3-9.3L4 10" /></svg>
}

function SettingsIcon() {
  return <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 15.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7Z" /><path d="M19.4 15a1.7 1.7 0 0 0 .34 1.88l.06.06-2.83 2.83-.06-.06a1.7 1.7 0 0 0-1.88-.34 1.7 1.7 0 0 0-1.03 1.56V21h-4v-.08A1.7 1.7 0 0 0 8.95 19.4a1.7 1.7 0 0 0-1.88.34l-.06.06-2.83-2.83.06-.06A1.7 1.7 0 0 0 4.6 15 1.7 1.7 0 0 0 3.08 14H3v-4h.08A1.7 1.7 0 0 0 4.6 8.95a1.7 1.7 0 0 0-.34-1.88L4.2 7l2.83-2.83.06.06a1.7 1.7 0 0 0 1.88.34A1.7 1.7 0 0 0 10 3.08V3h4v.08a1.7 1.7 0 0 0 1.05 1.52 1.7 1.7 0 0 0 1.88-.34l.06-.06L19.82 7l-.06.06a1.7 1.7 0 0 0-.34 1.88A1.7 1.7 0 0 0 20.92 10H21v4h-.08A1.7 1.7 0 0 0 19.4 15Z" /></svg>
}

export default function QuizGame({ questions }: { questions: GameQuestion[] }) {
  const [screen, setScreen] = useState<Screen>('welcome')
  const [names, setNames] = useState(['Oyuncu 1', 'Oyuncu 2'])
  const [questionIndex, setQuestionIndex] = useState(0)
  const [currentAnswers, setCurrentAnswers] = useState<[Answer, Answer]>([null, null])
  const [allAnswers, setAllAnswers] = useState<[Answer[], Answer[]]>([[], []])
  const [timeLeft, setTimeLeft] = useState(QUESTION_TIME)
  const [isRevealed, setIsRevealed] = useState(false)

  const hasEnoughQuestions = questions.length === REQUIRED_QUESTION_COUNT
  const question = questions[questionIndex]
  const scores = useMemo(
    () => allAnswers.map((answers) => answers.reduce(
      (total: number, answer, index) => total + (answer === questions[index]?.answer ? 1 : 0), 0,
    )),
    [allAnswers, questions],
  )

  useEffect(() => {
    if (screen !== 'quiz' || isRevealed) return
    const timer = window.setInterval(() => {
      setTimeLeft((current) => {
        if (current <= 1) {
          window.clearInterval(timer)
          setIsRevealed(true)
          return 0
        }
        return current - 1
      })
    }, 1000)
    return () => window.clearInterval(timer)
  }, [screen, questionIndex, isRevealed])

  function updateName(playerIndex: number, value: string) {
    setNames((previous) => {
      const next = [...previous]
      next[playerIndex] = value
      return next
    })
  }

  function startGame() {
    if (!hasEnoughQuestions) return
    setNames((previous) => previous.map((name, index) => name.trim() || `Oyuncu ${index + 1}`))
    setQuestionIndex(0)
    setCurrentAnswers([null, null])
    setAllAnswers([[], []])
    setTimeLeft(QUESTION_TIME)
    setIsRevealed(false)
    setScreen('quiz')
  }

  function answerQuestion(playerIndex: number, answer: boolean) {
    if (isRevealed || currentAnswers[playerIndex] !== null) return
    const nextAnswers: [Answer, Answer] = [...currentAnswers]
    nextAnswers[playerIndex] = answer
    setCurrentAnswers(nextAnswers)
    setAllAnswers((previous) => {
      const next: [Answer[], Answer[]] = [[...previous[0]], [...previous[1]]]
      next[playerIndex][questionIndex] = answer
      return next
    })
    if (nextAnswers.every((value) => value !== null)) setIsRevealed(true)
  }

  function nextQuestion() {
    if (!isRevealed) return
    if (questionIndex === questions.length - 1) {
      setScreen('results')
      return
    }
    setQuestionIndex((previous) => previous + 1)
    setCurrentAnswers([null, null])
    setTimeLeft(QUESTION_TIME)
    setIsRevealed(false)
  }

  function restart() {
    setScreen('welcome')
    setQuestionIndex(0)
    setCurrentAnswers([null, null])
    setAllAnswers([[], []])
    setTimeLeft(QUESTION_TIME)
    setIsRevealed(false)
  }

  if (screen === 'welcome') {
    return (
      <main className="app-shell welcome-screen">
        <div className="ambient ambient-one" /><div className="ambient ambient-two" />
        <header className="brand"><span className="brand-mark"><SparkIcon /></span><span>İKİLİ</span></header>
        <Link className="admin-link" href="/admin/collections/questions"><SettingsIcon />Soruları yönet</Link>
        <section className="welcome-card">
          <h1>Doğru mu,<br />yanlış mı?</h1>
          <p className="welcome-copy">15 soru, 2 oyuncu ve tek bir kazanan. Her soru için yalnızca 15 saniyen var!</p>
          <div className="name-grid">
            {names.map((name, index) => (
              <label className={`name-field player-${index + 1}-field`} key={index}>
                <span>{index + 1}. oyuncu</span>
                <input value={name} maxLength={18} onChange={(event) => updateName(index, event.target.value)}
                  onFocus={(event) => event.currentTarget.select()} aria-label={`${index + 1}. oyuncunun adı`} />
              </label>
            ))}
          </div>
          {!hasEnoughQuestions && (
            <div className="setup-notice" role="status">
              <strong>{questions.length}/15 soru hazır</strong>
              <span>Oyunu başlatmak için yönetim alanından 15 soru ekleyin.</span>
            </div>
          )}
          <button className="primary-button" disabled={!hasEnoughQuestions} onClick={startGame}>Oyunu başlat<ArrowIcon /></button>
          <p className="hint">Her oyuncu aynı soruya bir cevap verir.</p>
        </section>
        <div className="scribble scribble-left">15</div><div className="scribble scribble-right">?</div>
      </main>
    )
  }

  if (screen === 'results') {
    const isDraw = scores[0] === scores[1]
    const winnerIndex = scores[0] > scores[1] ? 0 : 1
    return (
      <main className="app-shell results-screen">
        <div className="confetti confetti-a" /><div className="confetti confetti-b" /><div className="confetti confetti-c" />
        <header className="brand"><span className="brand-mark"><SparkIcon /></span><span>İKİLİ</span></header>
        <section className="results-card">
          <div className="trophy" aria-hidden="true">
            <svg viewBox="0 0 64 64"><path d="M21 8h22v9c0 11-4.8 19-11 19s-11-8-11-19V8Z" /><path d="M21 13H10v5c0 8 5 12 13 12M43 13h11v5c0 8-5 12-13 12M32 36v10M23 54h18M27 46h10v8" /></svg>
          </div>
          <div className="eyebrow">Oyun tamamlandı</div>
          <h1>{isDraw ? 'Harika bir beraberlik!' : `Kazanan ${names[winnerIndex]}!`}</h1>
          <p className="result-subtitle">{isDraw ? 'İkiniz de aynı puanı aldınız. Rövanş zamanı!' : 'Bilgi düellosu sona erdi. İşte final tablosu:'}</p>
          <div className="score-grid">
            {names.map((name, playerIndex) => {
              const isWinner = !isDraw && playerIndex === winnerIndex
              return (
                <article className={`score-card player-${playerIndex + 1} ${isWinner ? 'winner' : ''}`} key={playerIndex}>
                  {isWinner && <span className="winner-badge">Kazanan</span>}
                  {isDraw && <span className="winner-badge">Berabere</span>}
                  <p>{name}</p>
                  <strong>{scores[playerIndex]}<small>/15</small></strong>
                  <div className="score-details">
                    <span><b>{scores[playerIndex]}</b> doğru</span>
                    <span><b>{questions.length - scores[playerIndex]}</b> yanlış</span>
                  </div>
                </article>
              )
            })}
          </div>
          <button className="primary-button restart-button" onClick={restart}><RestartIcon />Tekrar oyna</button>
        </section>
      </main>
    )
  }

  const timerStyle = { '--timer-progress': `${(timeLeft / QUESTION_TIME) * 360}deg` } as CSSProperties
  return (
    <main className="app-shell quiz-screen">
      <header className="quiz-header">
        <div className="brand compact-brand"><span className="brand-mark"><SparkIcon /></span><span>İKİLİ</span></div>
        <div className="progress-area">
          <div className="progress-meta"><span>Soru {questionIndex + 1}</span><span>{questions.length}</span></div>
          <div className="progress-track" role="progressbar" aria-valuemin={1} aria-valuemax={questions.length} aria-valuenow={questionIndex + 1} aria-label="Oyun ilerlemesi">
            <span style={{ width: `${((questionIndex + 1) / questions.length) * 100}%` }} />
          </div>
        </div>
        <div className={`timer ${timeLeft <= 5 ? 'timer-urgent' : ''}`} style={timerStyle} aria-label={`${timeLeft} saniye kaldı`}>
          <span>{timeLeft}</span><small>sn</small>
        </div>
      </header>
      <section className="question-panel"><span className="category">{question.category}</span><h1>{question.statement}</h1></section>
      <section className="players-grid">
        {names.map((name, playerIndex) => {
          const playerAnswer = currentAnswers[playerIndex]
          return (
            <article className={`player-panel player-${playerIndex + 1}`} key={playerIndex}>
              <div className="player-heading">
                <span className="player-number">0{playerIndex + 1}</span><h2>{name}</h2>
                {playerAnswer !== null && <span className="locked">Cevaplandı</span>}
                {isRevealed && playerAnswer === null && <span className="locked timeout-label">Süre doldu</span>}
              </div>
              <div className="answer-grid">
                <button className={`answer-button true-button ${playerAnswer === true ? 'selected' : ''} ${isRevealed && question.answer === true ? 'correct-answer' : ''} ${isRevealed && playerAnswer === true && !question.answer ? 'wrong-answer' : ''}`}
                  disabled={isRevealed || playerAnswer !== null} onClick={() => answerQuestion(playerIndex, true)} aria-label={`${name}: Doğru`}>
                  <span className="answer-icon">D</span><span>Doğru</span>
                </button>
                <button className={`answer-button false-button ${playerAnswer === false ? 'selected' : ''} ${isRevealed && question.answer === false ? 'correct-answer' : ''} ${isRevealed && playerAnswer === false && question.answer ? 'wrong-answer' : ''}`}
                  disabled={isRevealed || playerAnswer !== null} onClick={() => answerQuestion(playerIndex, false)} aria-label={`${name}: Yanlış`}>
                  <span className="answer-icon">Y</span><span>Yanlış</span>
                </button>
              </div>
            </article>
          )
        })}
      </section>
      <footer className={`quiz-footer ${isRevealed ? 'revealed' : ''}`}>
        {isRevealed ? (
          <>
            <div className="explanation"><span className="explanation-label">Cevap: {question.answer ? 'Doğru' : 'Yanlış'}</span><p>{question.explanation}</p></div>
            <button className="next-button" onClick={nextQuestion}>{questionIndex === questions.length - 1 ? 'Sonuçları gör' : 'Sıradaki soru'}<ArrowIcon /></button>
          </>
        ) : <p className="waiting-text"><span />İki oyuncunun cevabı bekleniyor · {timeLeft} saniye</p>}
      </footer>
    </main>
  )
}
