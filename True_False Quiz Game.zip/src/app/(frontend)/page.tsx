import config from '@payload-config'
import { unstable_cache } from 'next/cache'
import { getPayload } from 'payload'
import QuizGame, { type GameQuestion } from './quiz-game'

const getQuestions = unstable_cache(async (): Promise<GameQuestion[]> => {
  const payload = await getPayload({ config })
  const result = await payload.find({
    collection: 'questions',
    depth: 0,
    limit: 15,
    overrideAccess: false,
    pagination: false,
    sort: 'order',
  })

  return result.docs.map((question) => ({
    id: String(question.id),
    statement: question.statement,
    answer: question.answer === 'true',
    explanation: question.explanation,
    category: question.category,
  }))
}, ['quiz-questions'], { tags: ['quiz-questions'] })

export default async function HomePage() {
  const questions = await getQuestions()
  return <QuizGame questions={questions} />
}
